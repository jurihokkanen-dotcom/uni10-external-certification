namespace FSC

inductive TV3 where
  | F | U | T
  deriving DecidableEq, Repr
open TV3

def neg3 : TV3 -> TV3
  | F => T | U => U | T => F

def and3 : TV3 -> TV3 -> TV3
  | F, _ => F
  | _, F => F
  | T, T => T
  | _, _ => U

def or3 : TV3 -> TV3 -> TV3
  | T, _ => T
  | _, T => T
  | F, F => F
  | _, _ => U

def imp3 (a b : TV3) : TV3 := or3 (neg3 a) b

def forall3 : List TV3 -> TV3
  | [] => T
  | x :: xs => and3 x (forall3 xs)

def exists3 : List TV3 -> TV3
  | [] => F
  | x :: xs => or3 x (exists3 xs)

def LeInfo : TV3 -> TV3 -> Prop
  | U, _ => True
  | F, F => True
  | T, T => True
  | _, _ => False

structure Evidence4 where
  support : Bool
  oppose : Bool
  deriving DecidableEq, Repr

def eNeg (e : Evidence4) : Evidence4 := ⟨e.oppose, e.support⟩
def eJoin (a b : Evidence4) : Evidence4 :=
  ⟨a.support || b.support, a.oppose || b.oppose⟩

-- Product-state dimensions are intentionally distinct types. No coercions
-- between semantic truth, evidence, verification, solver, and lifecycle are
-- declared in the trusted kernel.
inductive VerificationState where
  | unverified | checked | independentlyChecked | replicated
  deriving DecidableEq, Repr

inductive SolverState where
  | proved | refuted | indeterminate | undecidableClass | resourceLimit | error
  deriving DecidableEq, Repr

inductive Precision where
  | approx | exact
  deriving DecidableEq, Repr

inductive Lifecycle where
  | raw | parsed | normalized | contextBound | evidenceLinked | inferenceChecked
  | verificationChecked | admissible | committed | ambiguous | contested
  | blocked | revalidationRequired | superseded | retracted
  deriving DecidableEq, Repr

structure ProductState where
  truth : TV3
  evidence : Evidence4
  verification : VerificationState
  solver : SolverState
  precision : Precision
  lifecycle : Lifecycle
  deriving DecidableEq, Repr

-- Compiled-proof candidates already explicit by finite case analysis.
theorem neg_involutive (a : TV3) : neg3 (neg3 a) = a := by
  cases a <;> rfl

theorem deMorgan_and (a b : TV3) : neg3 (and3 a b) = or3 (neg3 a) (neg3 b) := by
  cases a <;> cases b <;> rfl

theorem deMorgan_or (a b : TV3) : neg3 (or3 a b) = and3 (neg3 a) (neg3 b) := by
  cases a <;> cases b <;> rfl

theorem and_comm (a b : TV3) : and3 a b = and3 b a := by
  cases a <;> cases b <;> rfl

theorem or_comm (a b : TV3) : or3 a b = or3 b a := by
  cases a <;> cases b <;> rfl

theorem and_assoc (a b c : TV3) : and3 (and3 a b) c = and3 a (and3 b c) := by
  cases a <;> cases b <;> cases c <;> rfl

theorem or_assoc (a b c : TV3) : or3 (or3 a b) c = or3 a (or3 b c) := by
  cases a <;> cases b <;> cases c <;> rfl

theorem and_distrib_or (a b c : TV3) :
    and3 a (or3 b c) = or3 (and3 a b) (and3 a c) := by
  cases a <;> cases b <;> cases c <;> rfl

theorem or_distrib_and (a b c : TV3) :
    or3 a (and3 b c) = and3 (or3 a b) (or3 a c) := by
  cases a <;> cases b <;> cases c <;> rfl

theorem contraposition_imp (a b : TV3) : imp3 a b = imp3 (neg3 b) (neg3 a) := by
  cases a <;> cases b <;> rfl

theorem neg_info_monotone (a b : TV3) : LeInfo a b -> LeInfo (neg3 a) (neg3 b) := by
  cases a <;> cases b <;> simp [LeInfo, neg3]

theorem and_info_monotone (a a' b b' : TV3) :
    LeInfo a a' -> LeInfo b b' -> LeInfo (and3 a b) (and3 a' b') := by
  sorry

theorem or_info_monotone (a a' b b' : TV3) :
    LeInfo a a' -> LeInfo b b' -> LeInfo (or3 a b) (or3 a' b') := by
  cases a <;> cases a' <;> cases b <;> cases b' <;> simp [LeInfo, or3]

theorem imp_info_monotone (a a' b b' : TV3) :
    LeInfo a a' -> LeInfo b b' -> LeInfo (imp3 a b) (imp3 a' b') := by
  cases a <;> cases a' <;> cases b <;> cases b' <;> simp [LeInfo, imp3, neg3, or3]

theorem forall_exists_dual (xs : List TV3) :
    forall3 (xs.map neg3) = neg3 (exists3 xs) := by
  induction xs with
  | nil => rfl
  | cons a xs ih =>
      cases a <;> simp [forall3, exists3, neg3, and3, or3, ih]

theorem exists_forall_dual (xs : List TV3) :
    exists3 (xs.map neg3) = neg3 (forall3 xs) := by
  induction xs with
  | nil => rfl
  | cons a xs ih =>
      cases a <;> simp [forall3, exists3, neg3, and3, or3, ih]

theorem eJoin_comm (a b : Evidence4) : eJoin a b = eJoin b a := by
  cases a with
  | mk as_ ao =>
    cases b with
    | mk bs bo => simp [eJoin, Bool.or_comm]

theorem eJoin_assoc (a b c : Evidence4) : eJoin (eJoin a b) c = eJoin a (eJoin b c) := by
  cases a with
  | mk as_ ao =>
    cases b with
    | mk bs bo =>
      cases c with
      | mk cs co => simp [eJoin, Bool.or_assoc]

theorem eJoin_idem (a : Evidence4) : eJoin a a = a := by
  cases a with
  | mk as_ ao => simp [eJoin]

theorem eNeg_involutive (a : Evidence4) : eNeg (eNeg a) = a := by
  cases a <;> rfl

-- Remaining obligations intentionally remain explicit and unclaimed until a
-- Lean compiler accepts them: classical conservativity at formula level,
-- K3 determinate soundness wrt completion semantics, supervaluation refinement,
-- extensional equivalence relation/substitution, and SAT/UNSAT reductions.


-- FSC-R&D/0.7 inherited safety-layer source obligations.
inductive SafetyMode where
  | normal | degraded | safeBlocked | recovery | emergency
  deriving DecidableEq, Repr

inductive SafetySeverity where
  | s0 | s1 | s2 | s3 | s4
  deriving DecidableEq, Repr

def commitModeAllowed : SafetyMode -> Bool
  | SafetyMode.safeBlocked => false
  | SafetyMode.emergency => false
  | _ => true

theorem safeBlocked_rejects_commit :
    commitModeAllowed SafetyMode.safeBlocked = false := by rfl

theorem emergency_rejects_commit :
    commitModeAllowed SafetyMode.emergency = false := by rfl

theorem normal_allows_commit_mode_gate :
    commitModeAllowed SafetyMode.normal = true := by rfl

theorem degraded_allows_reference_fallback_commit_mode_gate :
    commitModeAllowed SafetyMode.degraded = true := by rfl

-- These mode theorems prove only the mode component of CommitEligible. Full
-- commit safety additionally requires verification, provenance, invariant and
-- dependency obligations, represented in the state-machine proof layer.


-- FSC-R&D/0.7 formula-level proof candidates. These remain unclaimed until
-- accepted by the pinned Lean 4.32.2 checker.

theorem neg3_eq_T_iff (a : TV3) : neg3 a = T ↔ a = F := by
  cases a <;> simp [neg3]

theorem neg3_eq_F_iff (a : TV3) : neg3 a = F ↔ a = T := by
  cases a <;> simp [neg3]

theorem and3_eq_T_iff (a b : TV3) : and3 a b = T ↔ a = T ∧ b = T := by
  cases a <;> cases b <;> simp [and3]

theorem and3_eq_F_iff (a b : TV3) : and3 a b = F ↔ a = F ∨ b = F := by
  cases a <;> cases b <;> simp [and3]

theorem or3_eq_T_iff (a b : TV3) : or3 a b = T ↔ a = T ∨ b = T := by
  cases a <;> cases b <;> simp [or3]

theorem or3_eq_F_iff (a b : TV3) : or3 a b = F ↔ a = F ∧ b = F := by
  cases a <;> cases b <;> simp [or3]

inductive Formula (α : Type) where
  | atom : α → Formula α
  | neg : Formula α → Formula α
  | conj : Formula α → Formula α → Formula α
  | disj : Formula α → Formula α → Formula α
  deriving Repr

open Formula

def eval3 {α : Type} (v : α → TV3) : Formula α → TV3
  | atom a => v a
  | neg p => neg3 (eval3 v p)
  | conj p q => and3 (eval3 v p) (eval3 v q)
  | disj p q => or3 (eval3 v p) (eval3 v q)

def eval2 {α : Type} (v : α → Bool) : Formula α → Bool
  | atom a => v a
  | neg p => !(eval2 v p)
  | conj p q => (eval2 v p) && (eval2 v q)
  | disj p q => (eval2 v p) || (eval2 v q)

def Refines {α : Type} (v3 : α → TV3) (v2 : α → Bool) : Prop :=
  ∀ a, match v3 a with
       | F => v2 a = false
       | U => True
       | T => v2 a = true

/-- Formula-level determinate K3 soundness with respect to every classical
completion. The first component covers K3=T, the second K3=F. -/
theorem eval3_determinate_sound {α : Type} (f : Formula α)
    (v3 : α → TV3) (v2 : α → Bool) (hRef : Refines v3 v2) :
    (eval3 v3 f = T → eval2 v2 f = true) ∧
    (eval3 v3 f = F → eval2 v2 f = false) := by
  induction f with
  | atom a =>
      constructor
      · intro h
        have hr := hRef a
        cases hv : v3 a with
        | F => simp [eval3, hv] at h
        | U => simp [eval3, hv] at h
        | T => simpa [eval3, hv] using hr
      · intro h
        have hr := hRef a
        cases hv : v3 a with
        | F => simpa [eval3, hv] using hr
        | U => simp [eval3, hv] at h
        | T => simp [eval3, hv] at h
  | neg p ih =>
      rcases ih with ⟨ihT, ihF⟩
      constructor
      · intro h
        have hpF : eval3 v3 p = F := (neg3_eq_T_iff (eval3 v3 p)).mp (by simpa [eval3] using h)
        have epF : eval2 v2 p = false := ihF hpF
        simp [eval2, epF]
      · intro h
        have hpT : eval3 v3 p = T := (neg3_eq_F_iff (eval3 v3 p)).mp (by simpa [eval3] using h)
        have epT : eval2 v2 p = true := ihT hpT
        simp [eval2, epT]
  | conj p q ihp ihq =>
      rcases ihp with ⟨ipT, ipF⟩
      rcases ihq with ⟨iqT, iqF⟩
      constructor
      · intro h
        have hpq := (and3_eq_T_iff (eval3 v3 p) (eval3 v3 q)).mp (by simpa [eval3] using h)
        have epT := ipT hpq.1
        have eqT := iqT hpq.2
        simp [eval2, epT, eqT]
      · intro h
        have hpq := (and3_eq_F_iff (eval3 v3 p) (eval3 v3 q)).mp (by simpa [eval3] using h)
        cases hpq with
        | inl hpF =>
            have epF := ipF hpF
            simp [eval2, epF]
        | inr hqF =>
            have eqF := iqF hqF
            simp [eval2, eqF]
  | disj p q ihp ihq =>
      rcases ihp with ⟨ipT, ipF⟩
      rcases ihq with ⟨iqT, iqF⟩
      constructor
      · intro h
        have hpq := (or3_eq_T_iff (eval3 v3 p) (eval3 v3 q)).mp (by simpa [eval3] using h)
        cases hpq with
        | inl hpT =>
            have epT := ipT hpT
            simp [eval2, epT]
        | inr hqT =>
            have eqT := iqT hqT
            simp [eval2, eqT]
      · intro h
        have hpq := (or3_eq_F_iff (eval3 v3 p) (eval3 v3 q)).mp (by simpa [eval3] using h)
        have epF := ipF hpq.1
        have eqF := iqF hpq.2
        simp [eval2, epF, eqF]

theorem k3_true_all_completions {α : Type} (f : Formula α)
    (v3 : α → TV3) (h : eval3 v3 f = T) :
    ∀ v2 : α → Bool, Refines v3 v2 → eval2 v2 f = true := by
  intro v2 href
  exact (eval3_determinate_sound f v3 v2 href).1 h

theorem k3_false_all_completions {α : Type} (f : Formula α)
    (v3 : α → TV3) (h : eval3 v3 f = F) :
    ∀ v2 : α → Bool, Refines v3 v2 → eval2 v2 f = false := by
  intro v2 href
  exact (eval3_determinate_sound f v3 v2 href).2 h

def SemEq3 {α : Type} (p q : Formula α) : Prop :=
  ∀ v : α → TV3, eval3 v p = eval3 v q

theorem semEq3_refl {α : Type} (p : Formula α) : SemEq3 p p := by
  intro v; rfl

theorem semEq3_symm {α : Type} {p q : Formula α} : SemEq3 p q → SemEq3 q p := by
  intro h v; exact (h v).symm

theorem semEq3_trans {α : Type} {p q r : Formula α} :
    SemEq3 p q → SemEq3 q r → SemEq3 p r := by
  intro hpq hqr v
  exact Eq.trans (hpq v) (hqr v)

theorem semEq3_neg_congr {α : Type} {p q : Formula α} :
    SemEq3 p q → SemEq3 (neg p) (neg q) := by
  intro h v
  simp [eval3, h v]

theorem semEq3_conj_congr {α : Type} {p p' q q' : Formula α} :
    SemEq3 p p' → SemEq3 q q' → SemEq3 (conj p q) (conj p' q') := by
  intro hp hq v
  simp [eval3, hp v, hq v]

theorem semEq3_disj_congr {α : Type} {p p' q q' : Formula α} :
    SemEq3 p p' → SemEq3 q q' → SemEq3 (disj p q) (disj p' q') := by
  intro hp hq v
  simp [eval3, hp v, hq v]

-- Security/safety assurance at the type layer: critical verification targets
-- are pinned externally; theorem acceptance is never inferred from the
-- presence of this source file alone.

end FSC

-- FSC-R&D/0.7 proof-closure candidates. These are source obligations until
-- actually accepted by the pinned Lean 4.32.2 toolchain and the independent
-- high-risk checker policy.

namespace FSC06
open FSC
open FSC.TV3
open FSC.Formula


def liftBool : Bool -> FSC.TV3
  | false => F
  | true => T

 theorem neg_liftBool (b : Bool) : FSC.neg3 (liftBool b) = liftBool (!b) := by
  cases b <;> rfl

 theorem and_liftBool (a b : Bool) : FSC.and3 (liftBool a) (liftBool b) = liftBool (a && b) := by
  cases a <;> cases b <;> rfl

 theorem or_liftBool (a b : Bool) : FSC.or3 (liftBool a) (liftBool b) = liftBool (a || b) := by
  cases a <;> cases b <;> rfl

 theorem classical_conservativity {α : Type} (f : FSC.Formula α) (v : α → Bool) :
    FSC.eval3 (fun a => liftBool (v a)) f = liftBool (FSC.eval2 v f) := by
  induction f with
  | atom a => rfl
  | neg p ih =>
      simpa [FSC.eval3, FSC.eval2, ih] using neg_liftBool (FSC.eval2 v p)
  | conj p q ihp ihq =>
      simpa [FSC.eval3, FSC.eval2, ihp, ihq] using and_liftBool (FSC.eval2 v p) (FSC.eval2 v q)
  | disj p q ihp ihq =>
      simpa [FSC.eval3, FSC.eval2, ihp, ihq] using or_liftBool (FSC.eval2 v p) (FSC.eval2 v q)

 def SuperTrue {α : Type} (f : FSC.Formula α) (v3 : α → FSC.TV3) : Prop :=
  ∀ v2 : α → Bool, FSC.Refines v3 v2 → FSC.eval2 v2 f = true

 def SuperFalse {α : Type} (f : FSC.Formula α) (v3 : α → FSC.TV3) : Prop :=
  ∀ v2 : α → Bool, FSC.Refines v3 v2 → FSC.eval2 v2 f = false

 theorem k3_true_implies_supertrue {α : Type} (f : FSC.Formula α) (v3 : α → FSC.TV3)
    (h : FSC.eval3 v3 f = T) : SuperTrue f v3 := by
  intro v2 href
  exact (FSC.eval3_determinate_sound f v3 v2 href).1 h

 theorem k3_false_implies_superfalse {α : Type} (f : FSC.Formula α) (v3 : α → FSC.TV3)
    (h : FSC.eval3 v3 f = F) : SuperFalse f v3 := by
  intro v2 href
  exact (FSC.eval3_determinate_sound f v3 v2 href).2 h

 def defaultCompletion {α : Type} (v3 : α → FSC.TV3) : α → Bool := fun a =>
  match v3 a with
  | F => false
  | U => false
  | T => true

 theorem defaultCompletion_refines {α : Type} (v3 : α → FSC.TV3) :
    FSC.Refines v3 (defaultCompletion v3) := by
  intro a
  cases h : v3 a <;> simp [FSC.Refines, defaultCompletion, h]

 theorem supertrue_superfalse_disjoint {α : Type} (f : FSC.Formula α) (v3 : α → FSC.TV3) :
    SuperTrue f v3 → SuperFalse f v3 → False := by
  intro ht hf
  have hr := defaultCompletion_refines v3
  have hT := ht (defaultCompletion v3) hr
  have hF := hf (defaultCompletion v3) hr
  simp [hT] at hF

 theorem semEq3_congr_neg {α : Type} {p q : FSC.Formula α}
    (h : FSC.SemEq3 p q) : FSC.SemEq3 (FSC.Formula.neg p) (FSC.Formula.neg q) :=
  FSC.semEq3_neg_congr h

end FSC06
