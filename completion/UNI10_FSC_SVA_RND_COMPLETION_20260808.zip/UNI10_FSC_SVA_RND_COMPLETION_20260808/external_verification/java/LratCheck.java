import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class LratCheck {
  static final class Result {
    String status="FAIL", error=""; int initialClauses=0, additions=0, emptyClauseId=0;
    String json() {
      return "{\"status\":\""+esc(status)+"\",\"initial_clauses\":"+initialClauses+
        ",\"additions\":"+additions+",\"empty_clause_id\":"+emptyClauseId+
        (error.isEmpty()?"":",\"error\":\""+esc(error)+"\"")+"}";
    }
    static String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n");}
  }
  static List<Integer> ints(String line) {
    var out=new ArrayList<Integer>();
    for(String s: line.trim().split("\\s+")) if(!s.isEmpty()) out.add(Integer.parseInt(s));
    return out;
  }
  static final class Cnf { Map<Integer,int[]> clauses=new HashMap<>(); int maxVar; }
  static Cnf readCnf(Path p) throws Exception {
    var c=new Cnf(); int id=1, declared=-1; boolean header=false;
    try(var br=Files.newBufferedReader(p)) {
      String line;
      while((line=br.readLine())!=null){
        line=line.trim(); if(line.isEmpty()||line.startsWith("c")) continue;
        if(line.startsWith("p ")){
          var f=line.split("\\s+"); if(f.length!=4||!f[0].equals("p")||!f[1].equals("cnf")) throw new Exception("bad header");
          c.maxVar=Integer.parseInt(f[2]); declared=Integer.parseInt(f[3]); header=true; continue;
        }
        if(!header) throw new Exception("clause before header");
        var a=ints(line); var clause=new ArrayList<Integer>(); boolean term=false;
        for(int x:a){ if(x==0){term=true;break;} if(x==Integer.MIN_VALUE||Math.abs(x)>c.maxVar||x==0) throw new Exception("literal exceeds maxvar"); clause.add(x); }
        if(!term) throw new Exception("unterminated clause");
        c.clauses.put(id++, clause.stream().mapToInt(Integer::intValue).toArray());
      }
    }
    if(declared<0||declared!=c.clauses.size()) throw new Exception("declared clauses mismatch");
    return c;
  }
  static void rup(int[] candidate,List<Integer> hints,Map<Integer,int[]> clauses,int maxVar) throws Exception {
    byte[] asn=new byte[maxVar+1];
    class A { boolean assign(int lit) throws Exception { if(lit==0||lit==Integer.MIN_VALUE||Math.abs(lit)>maxVar) throw new Exception("literal outside range"); int v=Math.abs(lit); byte val=(byte)(lit>0?1:-1); if(asn[v]==0){asn[v]=val;return false;} return asn[v]!=val; }}
    A a=new A();
    for(int lit:candidate) if(a.assign(-lit)) return;
    boolean conflict=false;
    for(int hid:hints){
      int[] cl=clauses.get(hid); if(cl==null) throw new Exception("unknown hint "+hid);
      boolean sat=false; int un=0,unit=0;
      for(int lit:cl){ if(lit==0||lit==Integer.MIN_VALUE||Math.abs(lit)>maxVar) throw new Exception("hint out of range"); byte v=asn[Math.abs(lit)]; if(v==0){un++;unit=lit;continue;} if((lit>0&&v==1)||(lit<0&&v==-1)){sat=true;break;} }
      if(sat) throw new Exception("hint satisfied");
      if(un==0){conflict=true;break;}
      if(un!=1) throw new Exception("hint not unit");
      if(a.assign(unit)){conflict=true;break;}
    }
    if(!conflict) throw new Exception("RUP hints did not derive conflict");
  }
  static Result check(Path cnf,Path lrat){
    var r=new Result();
    try{
      var c=readCnf(cnf); r.initialClauses=c.clauses.size(); int last=r.initialClauses;
      try(var br=Files.newBufferedReader(lrat)){
        String line;
        while((line=br.readLine())!=null){ line=line.trim(); if(line.isEmpty()||line.startsWith("c")) continue; var z=ints(line); if(z.size()<3) throw new Exception("short LRAT line"); int id=z.get(0); if(id<=last) throw new Exception("non-increasing clause id"); int i=1; var cand=new ArrayList<Integer>(); while(i<z.size()&&z.get(i)!=0)cand.add(z.get(i++)); if(i>=z.size())throw new Exception("missing first 0"); i++; var hints=new ArrayList<Integer>(); while(i<z.size()&&z.get(i)!=0){if(z.get(i)<0)throw new Exception("RAT/deletion unsupported");hints.add(z.get(i++));} if(i>=z.size())throw new Exception("missing second 0"); if(i!=z.size()-1)throw new Exception("trailing data"); int[] ca=cand.stream().mapToInt(Integer::intValue).toArray(); rup(ca,hints,c.clauses,c.maxVar); c.clauses.put(id,ca); last=id; r.additions++; if(ca.length==0)r.emptyClauseId=id; }
      }
      if(r.emptyClauseId==0) throw new Exception("no verified empty clause"); r.status="PASS";
    } catch(Exception e){ r.error=e.getClass().getSimpleName()+": "+e.getMessage(); }
    return r;
  }
  public static void main(String[] args){ if(args.length!=2){System.err.println("usage: LratCheck <cnf> <lrat>");System.exit(2);} var r=check(Path.of(args[0]),Path.of(args[1])); System.out.println(r.json()); if(!r.status.equals("PASS"))System.exit(1); }
}
