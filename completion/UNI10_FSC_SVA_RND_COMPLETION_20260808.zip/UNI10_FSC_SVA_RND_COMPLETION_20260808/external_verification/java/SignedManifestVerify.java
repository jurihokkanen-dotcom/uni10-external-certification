import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.regex.*;

public final class SignedManifestVerify {
  static byte[] pemDer(Path p) throws Exception {
    String s=Files.readString(p).replaceAll("-----BEGIN [^-]+-----","").replaceAll("-----END [^-]+-----","").replaceAll("\\s","");
    return Base64.getDecoder().decode(s);
  }
  static String hex(byte[] b){var sb=new StringBuilder();for(byte x:b)sb.append(String.format("%02x",x));return sb.toString();}
  static boolean safe(String p){ if(p.isEmpty()||p.startsWith("/")||p.contains("\\"))return false; Path q=Path.of(p).normalize(); return !q.isAbsolute()&&!q.startsWith("..")&&q.toString().replace(File.separatorChar,'/').equals(p); }
  public static void main(String[] a) throws Exception {
    if(a.length!=1){System.err.println("usage: SignedManifestVerify <root>");System.exit(2);} Path root=Path.of(a[0]);
    Path mp=root.resolve("assurance/SIGNED_CONTENT_MANIFEST.txt"); byte[] mb=Files.readAllBytes(mp); List<String> lines=Files.readAllLines(mp);
    MessageDigest md=MessageDigest.getInstance("SHA-256"); boolean hashes=true,sorted=true,paths=true;String prev=null;int n=0;
    Pattern pat=Pattern.compile("^([0-9a-f]{64})  (.+)$");
    for(String line:lines){ if(line.isEmpty())continue; var m=pat.matcher(line); if(!m.matches()){hashes=false;continue;} String h=m.group(1),p=m.group(2); n++; if(!safe(p))paths=false; if(prev!=null&&prev.compareTo(p)>=0)sorted=false;prev=p; Path f=root.resolve(p); if(!Files.isRegularFile(f)){hashes=false;continue;} if(!hex(md.digest(Files.readAllBytes(f))).equals(h))hashes=false; }
    byte[] der=pemDer(root.resolve("assurance/PUBLIC_KEY.pem")); PublicKey pk=KeyFactory.getInstance("Ed25519").generatePublic(new X509EncodedKeySpec(der)); byte[] sig=Files.readAllBytes(root.resolve("assurance/CONTENT_SIGNATURE.bin")); Signature v=Signature.getInstance("Ed25519");v.initVerify(pk);v.update(mb);boolean sigok=v.verify(sig);
    String fp=Files.readString(root.resolve("assurance/PUBLIC_KEY_FINGERPRINT_SHA256.txt")).trim(); boolean fpok=hex(md.digest(der)).equals(fp); String mh=hex(md.digest(mb));
    boolean ok=hashes&&sorted&&paths&&sigok&&fpok;
    System.out.println("{\"status\":\""+(ok?"PASS_INTEGRITY_ONLY":"FAIL")+"\",\"files\":"+n+",\"hashes_valid\":"+hashes+",\"strictly_sorted\":"+sorted+",\"paths_safe\":"+paths+",\"signature_valid\":"+sigok+",\"fingerprint_valid\":"+fpok+",\"manifest_sha256\":\""+mh+"\"}");
    if(!ok)System.exit(1);
  }
}
