#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct { int *a; int n; } Clause;
static int iabs(int x){ return x<0?-x:x; }
static void die(const char *m){ fprintf(stderr,"FAIL: %s\n",m); exit(1); }
static void ensure(Clause **cs,int *cap,int id){ if(id<*cap)return; int nc=*cap?*cap:32; while(nc<=id)nc*=2; *cs=realloc(*cs,(size_t)nc*sizeof(**cs)); if(!*cs)die("oom"); for(int i=*cap;i<nc;i++){(*cs)[i].a=NULL;(*cs)[i].n=-1;} *cap=nc; }
static int parse_line(char *s,int **out){ int cap=16,n=0; int *a=malloc((size_t)cap*sizeof(int)); if(!a)die("oom"); char *p=s; while(1){ while(isspace((unsigned char)*p))p++; if(!*p)break; char *e; long v=strtol(p,&e,10); if(e==p){free(a);return -1;} if(n==cap){cap*=2;a=realloc(a,(size_t)cap*sizeof(int));if(!a)die("oom");} a[n++]=(int)v;p=e;} *out=a; return n; }

static void read_cnf(const char *path,Clause **pcs,int *pcap,int *pn,int *pmaxv){ FILE *f=fopen(path,"r"); if(!f)die("open cnf"); char buf[65536]; Clause *cs=NULL; int cap=0,id=1,maxv=0,decl=0; while(fgets(buf,sizeof(buf),f)){ char *p=buf; while(isspace((unsigned char)*p))p++; if(!*p||*p=='c')continue; if(*p=='p'){ char pkw[8],ckw[8]; int nv,nc; if(sscanf(p,"%7s %7s %d %d",pkw,ckw,&nv,&nc)!=4||strcmp(pkw,"p")||strcmp(ckw,"cnf"))die("bad cnf header"); maxv=nv;decl=nc;continue;} int *v=NULL,n=parse_line(p,&v); if(n<1)die("bad clause"); int z=-1; for(int i=0;i<n;i++)if(v[i]==0){z=i;break;} if(z<0)die("unterminated cnf clause"); ensure(&cs,&cap,id); cs[id].n=z; cs[id].a=malloc((size_t)z*sizeof(int)); if(z&& !cs[id].a)die("oom"); for(int i=0;i<z;i++){if(iabs(v[i])>maxv)die("literal exceeds maxvar");cs[id].a[i]=v[i];} free(v);id++; }
 fclose(f); if(decl && decl!=id-1)die("cnf clause count mismatch"); *pcs=cs;*pcap=cap;*pn=id-1;*pmaxv=maxv; }

static int rup(Clause cand,int *h,int nh,Clause *cs,int cap,int maxv){ signed char *asn=calloc((size_t)maxv+1,1); if(!asn)die("oom");
 #define ASSIGN(LIT,CONFLICT) do{int _v=iabs(LIT); signed char _x=(LIT)>0?1:-1; if(asn[_v]==0)asn[_v]=_x; else if(asn[_v]!=_x)CONFLICT=1;}while(0)
 int conflict=0; for(int i=0;i<cand.n;i++){ if(iabs(cand.a[i])==0 || iabs(cand.a[i])>maxv){free(asn);return 0;} ASSIGN(-cand.a[i],conflict); if(conflict){free(asn);return 1;}}
 for(int k=0;k<nh;k++){int id=h[k]; if(id<=0||id>=cap||cs[id].n<0){free(asn);return 0;} Clause c=cs[id]; int sat=0,un=0,unit=0; for(int j=0;j<c.n;j++){int lit=c.a[j],v=iabs(lit); if(v==0||v>maxv){free(asn);return 0;} signed char av=asn[v]; if(!av){un++;unit=lit;} else if((lit>0&&av==1)||(lit<0&&av==-1)){sat=1;break;}} if(sat){free(asn);return 0;} if(un==0){conflict=1;break;} if(un!=1){free(asn);return 0;} ASSIGN(unit,conflict); if(conflict)break; }
 free(asn); return conflict;
 #undef ASSIGN
}

int main(int argc,char **argv){ if(argc!=3){fprintf(stderr,"usage: lrat-microcheck <cnf> <lrat>\n");return 2;} Clause *cs=NULL; int cap=0,n=0,maxv=0; read_cnf(argv[1],&cs,&cap,&n,&maxv); FILE *f=fopen(argv[2],"r"); if(!f)die("open lrat"); char buf[65536]; int last=n,adds=0,empty=0; while(fgets(buf,sizeof(buf),f)){char *p=buf;while(isspace((unsigned char)*p))p++;if(!*p||*p=='c')continue;int *v=NULL,nv=parse_line(p,&v);if(nv<3)die("bad lrat line");int id=v[0];if(id<=last)die("non-increasing id");int i=1,z1=-1;for(;i<nv;i++)if(v[i]==0){z1=i;break;}if(z1<0)die("missing first zero");Clause cand={.a=&v[1],.n=z1-1};int hs=z1+1,z2=-1;for(i=hs;i<nv;i++){if(v[i]<0)die("negative/RAT hint unsupported");if(v[i]==0){z2=i;break;}}if(z2<0||z2!=nv-1)die("bad hint terminator");if(!rup(cand,&v[hs],z2-hs,cs,cap,maxv))die("RUP failed");ensure(&cs,&cap,id);cs[id].n=cand.n;cs[id].a=malloc((size_t)cand.n*sizeof(int));if(cand.n&&!cs[id].a)die("oom");for(i=0;i<cand.n;i++)cs[id].a[i]=cand.a[i];last=id;adds++;if(cand.n==0)empty=id;free(v);}fclose(f);if(!empty)die("no empty clause");printf("PASS initial=%d additions=%d empty_clause_id=%d\n",n,adds,empty);return 0;}
