package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Clause []int

type Result struct {
	Status         string `json:"status"`
	InitialClauses int    `json:"initial_clauses"`
	Additions      int    `json:"additions"`
	EmptyClauseID  int    `json:"empty_clause_id"`
	Error          string `json:"error,omitempty"`
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
func parseInts(line string) ([]int, error) {
	fs := strings.Fields(line)
	a := make([]int, len(fs))
	for i, s := range fs {
		v, e := strconv.Atoi(s)
		if e != nil {
			return nil, e
		}
		a[i] = v
	}
	return a, nil
}

func readCNF(path string) (map[int]Clause, int, int, error) {
	f, e := os.Open(path)
	if e != nil {
		return nil, 0, 0, e
	}
	defer f.Close()
	clauses := map[int]Clause{}
	sc := bufio.NewScanner(f)
	id := 1
	maxv := 0
	declared := 0
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "c") {
			continue
		}
		if strings.HasPrefix(line, "p ") {
			var p, cnf string
			var nv, nc int
			if _, e := fmt.Sscanf(line, "%s %s %d %d", &p, &cnf, &nv, &nc); e != nil {
				return nil, 0, 0, e
			}
			if p != "p" || cnf != "cnf" {
				return nil, 0, 0, fmt.Errorf("bad header")
			}
			maxv = nv
			declared = nc
			continue
		}
		ints, e := parseInts(line)
		if e != nil {
			return nil, 0, 0, e
		}
		c := Clause{}
		term := false
		for _, x := range ints {
			if x == 0 {
				term = true
				break
			}
			if abs(x) > maxv {
				return nil, 0, 0, fmt.Errorf("literal exceeds maxvar")
			}
			c = append(c, x)
		}
		if !term {
			return nil, 0, 0, fmt.Errorf("unterminated clause")
		}
		clauses[id] = c
		id++
	}
	if e := sc.Err(); e != nil {
		return nil, 0, 0, e
	}
	if declared != 0 && declared != len(clauses) {
		return nil, 0, 0, fmt.Errorf("declared clauses mismatch")
	}
	return clauses, len(clauses), maxv, nil
}

// RUP with explicit positive LRAT hints. Start with negation of the candidate clause.
func rup(candidate Clause, hints []int, clauses map[int]Clause, maxv int) error {
	asn := make([]int8, maxv+1) // 0 unset, 1 true, -1 false
	assign := func(lit int) (bool, bool) {
		v := abs(lit)
		val := int8(1)
		if lit < 0 {
			val = -1
		}
		if asn[v] == 0 {
			asn[v] = val
			return true, false
		}
		if asn[v] != val {
			return false, true
		}
		return false, false
	}
	for _, lit := range candidate {
		if abs(lit) == 0 || abs(lit) > maxv {
			return fmt.Errorf("candidate literal %d outside 1..%d", lit, maxv)
		}
		_, conf := assign(-lit)
		if conf {
			return nil
		}
	}
	conflict := false
	for _, hid := range hints {
		c, ok := clauses[hid]
		if !ok {
			return fmt.Errorf("unknown hint %d", hid)
		}
		sat := false
		un := 0
		unit := 0
		for _, lit := range c {
			if abs(lit) == 0 || abs(lit) > maxv {
				return fmt.Errorf("hint %d contains out-of-range literal %d", hid, lit)
			}
			v := asn[abs(lit)]
			if v == 0 {
				un++
				unit = lit
				continue
			}
			if (lit > 0 && v == 1) || (lit < 0 && v == -1) {
				sat = true
				break
			}
		}
		if sat {
			return fmt.Errorf("hint %d satisfied, not a unit/conflict step", hid)
		}
		if un == 0 {
			conflict = true
			break
		}
		if un != 1 {
			return fmt.Errorf("hint %d not unit: %d unassigned", hid, un)
		}
		_, conf := assign(unit)
		if conf {
			conflict = true
			break
		}
	}
	if !conflict {
		return fmt.Errorf("RUP hints did not derive conflict")
	}
	return nil
}

func check(cnf, lrat string) Result {
	clauses, n, maxv, e := readCNF(cnf)
	if e != nil {
		return Result{Status: "FAIL", Error: e.Error()}
	}
	f, e := os.Open(lrat)
	if e != nil {
		return Result{Status: "FAIL", Error: e.Error()}
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	additions := 0
	empty := 0
	lastID := n
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "c") {
			continue
		}
		ints, e := parseInts(line)
		if e != nil {
			return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: e.Error()}
		}
		if len(ints) < 3 {
			return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: "short LRAT line"}
		}
		id := ints[0]
		if id <= lastID {
			return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: "non-increasing clause id"}
		}
		i := 1
		cand := Clause{}
		for i < len(ints) && ints[i] != 0 {
			cand = append(cand, ints[i])
			i++
		}
		if i >= len(ints) {
			return Result{Status: "FAIL", Error: "missing first 0"}
		}
		i++
		hints := []int{}
		for i < len(ints) && ints[i] != 0 {
			if ints[i] < 0 {
				return Result{Status: "FAIL", Error: "RAT/deletion hints unsupported in RUP-only profile"}
			}
			hints = append(hints, ints[i])
			i++
		}
		if i >= len(ints) {
			return Result{Status: "FAIL", Error: "missing second 0"}
		}
		if i != len(ints)-1 {
			return Result{Status: "FAIL", Error: "trailing data"}
		}
		if e := rup(cand, hints, clauses, maxv); e != nil {
			return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: fmt.Sprintf("clause %d: %v", id, e)}
		}
		clauses[id] = cand
		lastID = id
		additions++
		if len(cand) == 0 {
			empty = id
		}
	}
	if e := sc.Err(); e != nil {
		return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: e.Error()}
	}
	if empty == 0 {
		return Result{Status: "FAIL", InitialClauses: n, Additions: additions, Error: "no verified empty clause"}
	}
	return Result{Status: "PASS", InitialClauses: n, Additions: additions, EmptyClauseID: empty}
}
func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "usage: lrat-go <cnf> <lrat>")
		os.Exit(2)
	}
	r := check(os.Args[1], os.Args[2])
	b, _ := json.Marshal(r)
	fmt.Println(string(b))
	if r.Status != "PASS" {
		os.Exit(1)
	}
}
