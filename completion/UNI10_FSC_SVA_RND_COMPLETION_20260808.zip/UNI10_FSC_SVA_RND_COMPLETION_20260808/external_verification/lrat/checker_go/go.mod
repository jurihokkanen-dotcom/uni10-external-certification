module fsc-lrat-checker

go 1.23
