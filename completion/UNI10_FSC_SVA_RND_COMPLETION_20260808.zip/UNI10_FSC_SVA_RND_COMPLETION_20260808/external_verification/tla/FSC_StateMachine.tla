------------------------ MODULE FSC_StateMachine ------------------------
EXTENDS Naturals, Sequences, FiniteSets

CONSTANTS Claims, Invariants, DependsOn, ApplicableInv

ClaimStates == {
  "RAW", "PARSED", "NORMALIZED", "CONTEXT_BOUND",
  "EVIDENCE_LINKED", "INFERENCE_CHECKED", "VERIFICATION_CHECKED",
  "ADMISSIBLE", "COMMITTED", "AMBIGUOUS", "CONTESTED",
  "BLOCKED", "REVALIDATION_REQUIRED", "SUPERSEDED", "RETRACTED"
}
TruthStates == {"F", "U", "T"}
EvidenceStates == {"NONE", "SUPPORT", "OPPOSE", "BOTH"}
SolverStates == {"PROVED", "REFUTED", "INDETERMINATE", "UNDECIDABLE_CLASS", "RESOURCE_LIMIT", "ERROR"}
SafetyModes == {"NORMAL", "DEGRADED", "SAFE_BLOCKED", "RECOVERY", "EMERGENCY"}
BlockingModes == {"SAFE_BLOCKED", "EMERGENCY"}

VARIABLES cstate, truth, evidence, solver, verificationOK, provenanceOK,
          history, invariantOK, version, trustedKernelOK, optimizerOK, safetyMode
vars == <<cstate, truth, evidence, solver, verificationOK, provenanceOK,
          history, invariantOK, version, trustedKernelOK, optimizerOK, safetyMode>>

RECURSIVE DepClosureN(_, _)
DepClosureN(S, n) ==
  IF n = 0 THEN S
  ELSE LET Prev == DepClosureN(S, n - 1)
       IN Prev \cup {c \in Claims : \E d \in DependsOn[c] : d \in Prev}

DepClosure(S) == DepClosureN(S, Cardinality(Claims))
DirectAffected(i) == {c \in Claims : i \in ApplicableInv[c]}
AffectedByInvariant(i) == DepClosure(DirectAffected(i))
DependentsOf(c) == DepClosure({c})

AllApplicableInvariantsOK(c) == \A i \in ApplicableInv[c] : invariantOK[i] = TRUE
DependenciesCommitted(c) == \A d \in DependsOn[c] : cstate[d] = "COMMITTED"
CommitEligible(c) ==
  /\ trustedKernelOK
  /\ safetyMode \notin BlockingModes
  /\ cstate[c] = "ADMISSIBLE"
  /\ verificationOK[c]
  /\ provenanceOK[c]
  /\ AllApplicableInvariantsOK(c)
  /\ DependenciesCommitted(c)

NoRevalidationPending == \A c \in Claims : cstate[c] # "REVALIDATION_REQUIRED"

Init ==
  /\ cstate = [c \in Claims |-> "RAW"]
  /\ truth = [c \in Claims |-> "U"]
  /\ evidence = [c \in Claims |-> "NONE"]
  /\ solver = [c \in Claims |-> "INDETERMINATE"]
  /\ verificationOK = [c \in Claims |-> FALSE]
  /\ provenanceOK = [c \in Claims |-> FALSE]
  /\ history = <<>>
  /\ invariantOK = [i \in Invariants |-> TRUE]
  /\ version = 0
  /\ trustedKernelOK = TRUE
  /\ optimizerOK = TRUE
  /\ safetyMode = "NORMAL"

NormalStep(from, to) == <<from,to>> \in {
  <<"RAW","PARSED">>,
  <<"PARSED","NORMALIZED">>,
  <<"NORMALIZED","CONTEXT_BOUND">>,
  <<"CONTEXT_BOUND","EVIDENCE_LINKED">>,
  <<"EVIDENCE_LINKED","INFERENCE_CHECKED">>,
  <<"INFERENCE_CHECKED","VERIFICATION_CHECKED">>,
  <<"VERIFICATION_CHECKED","ADMISSIBLE">>
}

Advance(c, to) ==
  /\ c \in Claims
  /\ to \in ClaimStates
  /\ NormalStep(cstate[c], to)
  /\ cstate' = [cstate EXCEPT ![c] = to]
  /\ history' = Append(history, <<"ADVANCE", version + 1, c, cstate[c], to>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

Commit(c) ==
  /\ c \in Claims
  /\ CommitEligible(c)
  /\ cstate' = [cstate EXCEPT ![c] = "COMMITTED"]
  /\ history' = Append(history, <<"COMMIT", version + 1, c>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

SetVerification(c, ok) ==
  /\ c \in Claims
  /\ ok \in BOOLEAN
  /\ verificationOK' = [verificationOK EXCEPT ![c] = ok]
  /\ cstate' = [x \in Claims |->
       IF ~ok /\ x \in DependentsOf(c) /\ cstate[x] = "COMMITTED"
       THEN "REVALIDATION_REQUIRED"
       ELSE cstate[x]]
  /\ history' = Append(history, <<"VERIFICATION", version + 1, c, ok>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, provenanceOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

SetProvenance(c, ok) ==
  /\ c \in Claims
  /\ ok \in BOOLEAN
  /\ provenanceOK' = [provenanceOK EXCEPT ![c] = ok]
  /\ cstate' = [x \in Claims |->
       IF ~ok /\ x \in DependentsOf(c) /\ cstate[x] = "COMMITTED"
       THEN "REVALIDATION_REQUIRED"
       ELSE cstate[x]]
  /\ history' = Append(history, <<"PROVENANCE", version + 1, c, ok>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

SetInvariant(i, ok) ==
  /\ i \in Invariants
  /\ ok \in BOOLEAN
  /\ invariantOK' = [invariantOK EXCEPT ![i] = ok]
  /\ cstate' = [c \in Claims |->
       IF ~ok /\ c \in AffectedByInvariant(i) /\ cstate[c] = "COMMITTED"
       THEN "REVALIDATION_REQUIRED"
       ELSE cstate[c]]
  /\ history' = Append(history, <<"INVARIANT", version + 1, i, ok>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

MaterialMutation(c, newTruth, newEvidence, newSolver) ==
  /\ c \in Claims
  /\ newTruth \in TruthStates
  /\ newEvidence \in EvidenceStates
  /\ newSolver \in SolverStates
  /\ truth' = [truth EXCEPT ![c] = newTruth]
  /\ evidence' = [evidence EXCEPT ![c] = newEvidence]
  /\ solver' = [solver EXCEPT ![c] = newSolver]
  /\ cstate' = [x \in Claims |->
       IF x \in DependentsOf(c) /\ cstate[x] = "COMMITTED"
       THEN "REVALIDATION_REQUIRED"
       ELSE cstate[x]]
  /\ history' = Append(history, <<"MUTATION", version + 1, c>>)
  /\ version' = version + 1
  /\ UNCHANGED <<verificationOK, provenanceOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

SetTrustedKernel(ok) ==
  /\ ok \in BOOLEAN
  /\ trustedKernelOK' = ok
  /\ cstate' = [c \in Claims |->
       IF ~ok /\ cstate[c] = "COMMITTED"
       THEN "REVALIDATION_REQUIRED"
       ELSE cstate[c]]
  /\ safetyMode' = IF ~ok THEN "SAFE_BLOCKED"
                    ELSE IF ~trustedKernelOK THEN "RECOVERY"
                    ELSE safetyMode
  /\ history' = Append(history, <<"TRUSTED_KERNEL", version + 1, ok>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK, invariantOK, optimizerOK>>

SetOptimizer(ok) ==
  /\ ok \in BOOLEAN
  /\ optimizerOK' = ok
  /\ safetyMode' = IF ~ok /\ safetyMode = "NORMAL" THEN "DEGRADED"
                    ELSE IF ok /\ safetyMode = "DEGRADED" THEN "NORMAL"
                    ELSE safetyMode
  /\ history' = Append(history, <<"OPTIMIZER", version + 1, ok>>)
  /\ version' = version + 1
  /\ UNCHANGED <<cstate, truth, evidence, solver, verificationOK, provenanceOK, invariantOK, trustedKernelOK>>

EmergencyBlock ==
  /\ cstate' = [c \in Claims |-> IF cstate[c] = "COMMITTED" THEN "REVALIDATION_REQUIRED" ELSE cstate[c]]
  /\ safetyMode' = "EMERGENCY"
  /\ history' = Append(history, <<"EMERGENCY", version + 1>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK, invariantOK, trustedKernelOK, optimizerOK>>

ClearEmergency ==
  /\ safetyMode = "EMERGENCY"
  /\ trustedKernelOK
  /\ safetyMode' = "RECOVERY"
  /\ history' = Append(history, <<"CLEAR_EMERGENCY", version + 1>>)
  /\ version' = version + 1
  /\ UNCHANGED <<cstate, truth, evidence, solver, verificationOK, provenanceOK, invariantOK, trustedKernelOK, optimizerOK>>

Revalidate(c) ==
  /\ c \in Claims
  /\ safetyMode = "RECOVERY"
  /\ trustedKernelOK
  /\ cstate[c] = "REVALIDATION_REQUIRED"
  /\ verificationOK[c]
  /\ provenanceOK[c]
  /\ AllApplicableInvariantsOK(c)
  /\ DependenciesCommitted(c)
  /\ cstate' = [cstate EXCEPT ![c] = "COMMITTED"]
  /\ history' = Append(history, <<"REVALIDATE", version + 1, c>>)
  /\ version' = version + 1
  /\ UNCHANGED <<truth, evidence, solver, verificationOK, provenanceOK, invariantOK,
                  trustedKernelOK, optimizerOK, safetyMode>>

CompleteRecovery ==
  /\ safetyMode = "RECOVERY"
  /\ trustedKernelOK
  /\ NoRevalidationPending
  /\ safetyMode' = "NORMAL"
  /\ history' = Append(history, <<"COMPLETE_RECOVERY", version + 1>>)
  /\ version' = version + 1
  /\ UNCHANGED <<cstate, truth, evidence, solver, verificationOK, provenanceOK, invariantOK, trustedKernelOK, optimizerOK>>

Next ==
  \/ \E c \in Claims, to \in ClaimStates : Advance(c, to)
  \/ \E c \in Claims : Commit(c)
  \/ \E c \in Claims, ok \in BOOLEAN : SetVerification(c, ok)
  \/ \E c \in Claims, ok \in BOOLEAN : SetProvenance(c, ok)
  \/ \E i \in Invariants, ok \in BOOLEAN : SetInvariant(i, ok)
  \/ \E c \in Claims, t \in TruthStates, e \in EvidenceStates, s \in SolverStates : MaterialMutation(c,t,e,s)
  \/ \E ok \in BOOLEAN : SetTrustedKernel(ok)
  \/ \E ok \in BOOLEAN : SetOptimizer(ok)
  \/ EmergencyBlock
  \/ ClearEmergency
  \/ \E c \in Claims : Revalidate(c)
  \/ CompleteRecovery

TypeOK ==
  /\ cstate \in [Claims -> ClaimStates]
  /\ truth \in [Claims -> TruthStates]
  /\ evidence \in [Claims -> EvidenceStates]
  /\ solver \in [Claims -> SolverStates]
  /\ verificationOK \in [Claims -> BOOLEAN]
  /\ provenanceOK \in [Claims -> BOOLEAN]
  /\ invariantOK \in [Invariants -> BOOLEAN]
  /\ trustedKernelOK \in BOOLEAN
  /\ optimizerOK \in BOOLEAN
  /\ safetyMode \in SafetyModes
  /\ version \in Nat

CommittedImpliesSafe ==
  \A c \in Claims : cstate[c] = "COMMITTED" =>
    /\ trustedKernelOK
    /\ safetyMode \notin BlockingModes
    /\ verificationOK[c]
    /\ provenanceOK[c]
    /\ AllApplicableInvariantsOK(c)
    /\ DependenciesCommitted(c)

SelectiveInvalidationSafety ==
  \A i \in Invariants : ~invariantOK[i] =>
    \A c \in AffectedByInvariant(i) : cstate[c] # "COMMITTED"

BlockingModeHasNoCommitted ==
  safetyMode \in BlockingModes => \A c \in Claims : cstate[c] # "COMMITTED"

NormalRequiresHealthyKernel ==
  safetyMode = "NORMAL" => trustedKernelOK

OptimizerFailureNotNormal ==
  ~optimizerOK => safetyMode # "NORMAL"

Spec == Init /\ [][Next]_vars
Safety == TypeOK /\ CommittedImpliesSafe /\ SelectiveInvalidationSafety
          /\ BlockingModeHasNoCommitted /\ NormalRequiresHealthyKernel
          /\ OptimizerFailureNotNormal

=============================================================================
\* FSC-R&D/0.7 source candidate. The Python bounded checker is executable and
\* independent of TLC. This TLA+ source must be parsed/model-checked by an
\* external TLA+ toolchain before claiming TLA+ machine verification.
