--------------------------- MODULE FSC_Recovery ---------------------------
EXTENDS Naturals, FiniteSets

CONSTANTS Claims, DependsOn
VARIABLES pending, committed, mode
vars == <<pending, committed, mode>>

Modes == {"RECOVERY", "NORMAL"}

Init ==
  /\ pending = Claims
  /\ committed = {}
  /\ mode = "RECOVERY"

Ready(c) ==
  /\ mode = "RECOVERY"
  /\ c \in pending
  /\ DependsOn[c] \subseteq committed

Revalidate(c) ==
  /\ Ready(c)
  /\ pending' = pending \ {c}
  /\ committed' = committed \cup {c}
  /\ UNCHANGED mode

Finish ==
  /\ mode = "RECOVERY"
  /\ pending = {}
  /\ mode' = "NORMAL"
  /\ UNCHANGED <<pending, committed>>

Next ==
  \/ \E c \in Claims : Revalidate(c)
  \/ Finish

TypeOK ==
  /\ pending \subseteq Claims
  /\ committed \subseteq Claims
  /\ mode \in Modes

Partition == pending \cap committed = {}
Coverage == pending \cup committed = Claims
NormalImpliesComplete == mode = "NORMAL" => pending = {}

Spec ==
  /\ Init
  /\ [][Next]_vars
  /\ (\A c \in Claims : WF_vars(Revalidate(c)))
  /\ WF_vars(Finish)

Safety == TypeOK /\ Partition /\ Coverage /\ NormalImpliesComplete
RecoveryEventuallyNormal == <>(mode = "NORMAL")

=============================================================================
\* Conditional recovery model. The model assumes a finite acyclic DependsOn
\* relation through the concrete model configuration. Fairness applies only to
\* enabled recovery work; new failures are intentionally absent from this
\* liveness-only model. FSC-R&D/0.7 does not claim this property machine-checked
\* until TLC 1.7.4 executes it under the pinned single-worker profile.
