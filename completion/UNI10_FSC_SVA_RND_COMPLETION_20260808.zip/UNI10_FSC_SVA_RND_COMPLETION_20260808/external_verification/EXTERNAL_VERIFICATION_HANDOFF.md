# External Verification Handoff

This package is the stopping boundary for local R&D. No external checker is counted as executed.

## 1. Lean 4.32.2
Use a clean, non-privileged environment and the included `lean-toolchain`. From `external_verification/lean` run:

```bash
lean --version
lean FSC_Core.lean
```

Record the exact Lean binary hash, version output, command, stdout/stderr and exit code.

## 2. Comparator + nanoda
Comparator requires a trusted Challenge/Solution project plus `landrun` and `lean4export`; enable nanoda for the high-risk profile. The FSC source is not silently rewritten into a Challenge/Solution pair by this package. First create and freeze a separately reviewed adapter that preserves theorem statements exactly, then run comparator under its documented sandbox assumptions. Any adapter mismatch is a blocking finding.

## 3. TLC 1.7.4
Verify `tla2tools.jar` SHA-1 equals `bee4a54f3ee3d4afc347c3240ec2d9e93b075104`. Critical profile uses one worker:

```bash
java -cp tla2tools.jar tlc2.TLC -workers 1 -config FSC_StateMachine.cfg FSC_StateMachine.tla
java -cp tla2tools.jar tlc2.TLC -workers 1 -config FSC_Recovery.cfg FSC_Recovery.tla
```

Both safety invariants and `RecoveryEventuallyNormal` must pass.

## 4. External LRAT
Run all 15 `cnf/*.cnf` / `lrat/*.lrat` pairs through a pinned standard LRAT checker (e.g. `lrat-check` or `cake_lpr`). Record checker revision/binary hash. All valid proofs must pass; adversarial/mutant proofs must be rejected.

## 5. Status rule
`TARGET_DECLARED`, `BINARY_PRESENT`, `EXECUTED`, and `INDEPENDENTLY_RECHECKED` are distinct states. Any checker disagreement, proof adapter mismatch, version drift, checksum mismatch, or unrecorded command blocks promotion.
