#!/usr/bin/env python3
import pathlib,hashlib,json,zipfile,sys
r=pathlib.Path(sys.argv[1])
h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
s=json.loads((r/'governance/PROJECT_COMPLETION_STATE.json').read_text()); d=json.loads((r/'governance/DEFINITION_OF_DONE.json').read_text())
f=r/'artifacts/FSC-RND_0.9_EXTERNAL_VERIFIER_CLOSURE_CANDIDATE.zip'; v=r/'artifacts/SVA-vNext_RND_0.1_ARCHITECTURE_CANDIDATE.zip'
assert h(f)==s['fsc_assurance_candidate']['archive_sha256']=='4978da81fb6c557c35de498015eba5f477170959de33ce2a336ba2faf821a921'
assert h(v)==s['sva_vnext_candidate']['archive_sha256']=='6402b282f4d04d76ffe2ab3c173507852a306423d68517c1cb31f4c344ab57b2'
for p in [f,v]:
 with zipfile.ZipFile(p) as z: assert z.testzip() is None
assert s['active_baseline_modified'] is False
assert d['promotion']=='FORBIDDEN'
assert s['sva_vnext_candidate']['blind_holdout_created'] is False
print('PASS')
